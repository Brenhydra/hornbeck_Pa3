import java.nio.ShortBuffer;

 class Hornbeck_p2 {
     private static double annualInterestRate=0;
            private double savingsBalance;

            public Hornbeck_p2(double balance)
            {
                savingsBalance=balance;
            }
            public void calculateMonthlyInterest()
            {
                savingsBalance+=savingsBalance*(annualInterestRate/12.0);
            }
            public static void modifyInterestRate (double newRate)
            {
                annualInterestRate=(newRate>=0 && newRate<=1.0)
                        ?newRate:0.04;
            }
            public String toString()
            {
                return String.format("$.2f", savingsBalance);
            }
        }
        class SavingsAccountTest
        {
            public static void main(String[] args)
            {
                Hornbeck_p2 saver1=new Hornbeck_p2(2000);
                Hornbeck_p2 saver2=new Hornbeck_p2(3000);

                Hornbeck_p2.modifyInterestRate(0.04);
                System.out.println("Balances");
                System.out.printf("%20s%10s\n","saver1","saver2");
                System.out.printf("%-10s%10s%10s\n","Base",saver1.toString(),saver2.toString());

                for (int month=1;month<=12;month++) {
                    String monthLabel = String.format("Month %d:", month);
                    saver1.calculateMonthlyInterest();
                    saver2.calculateMonthlyInterest();
                    System.out.printf("%-10s%10s%10s\n", monthLabel, saver1.toString(), saver2.toString());
                }
                Hornbeck_p2.modifyInterestRate(0.05);
                saver1.calculateMonthlyInterest();
                saver2.calculateMonthlyInterest();
                    System.out.println("\nWhen we increase the interest rate to five percent");
                    System.out.println("Balances:");
                    System.out.printf("-10s%10s\n","saver1","saver2");
                    System.out.printf("%-10s%10s",saver1.toString(),saver2.toString());
            }
        }
